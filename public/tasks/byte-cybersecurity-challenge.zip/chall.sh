#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$DIR/ld-linux.so.2" --library-path "$DIR" "$DIR/chall" "$@"
